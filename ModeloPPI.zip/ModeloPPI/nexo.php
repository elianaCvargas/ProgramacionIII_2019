<?php
include "Clases/alumno.php";
include "Clases/personaDAO.php";
include "Clases/archivero.php";
include "Clases/materia.php";
include "Clases/materiaArchivero.php";
include "Clases/inscripcionArchivero.php";
include "Clases/inscripcion.php";

if($_SERVER["REQUEST_METHOD"] == "POST")
{
    if(isset($_POST["caso"]))
    {
        switch($_POST["caso"])
        {
            case "cargarAlumno":
                echo "Cargo alumno...\n";
                $nombre;
                $apellido;
                $email;
                $foto;
                if(isset($_POST["nombre"]) && isset($_POST["apellido"]) 
                && isset($_POST["email"]) && isset($_FILES["foto"]))
                {
                    $nombre = $_POST["nombre"];
                    $apellido = $_POST["apellido"];
                    $email = $_POST["email"];
                    $foto = $_FILES["foto"]["name"];
                    $persona = new Alumno($nombre, $apellido, $email, $foto);
                    // personaDAO::Guardar($persona);//esto es un array
                    // personaDAO::ListarAlumnos($persona);
                    $alumnoJson = json_encode($persona);
                    // $persona->setId(0);
                    // var_dump($persona->setId(0));
                    echo archivero::GuardarArchivo($alumnoJson, "Alumno.txt", $persona); 
                }
                else
                {
                    echo "Falta definir algunos paràmetros";
                }
                break;

            case "consultarAlumno":
                echo "Consultando...\n";
                if(isset($_GET["apellido"]))
                {
                    echo archivero::MostrarEncontrados($_GET["apellido"], "Alumno.txt");
                }
                else
                {
                    echo "no se está definido el filtro de búsqueda";
                }
                break;

            case "cargarMateria":
                $nombre;
                $cupo;
                $aula;
                if(isset($_POST["nombre"]) 
                && isset($_POST["cupo"]) && isset($_POST["aula"]))
                {
                    $nombre = $_POST["nombre"];
                    //$codigo = $_POST["codigo"];
                    $cupo = $_POST["cupo"];
                    $aula = $_POST["aula"];
                    $materia = new Materia($nombre, $cupo, $aula);
                    $materia->setId(0);
                    $materia->setCodigoString($materia->getId());
                    $materiaJson = json_encode($materia);
                    echo materiaArchivero::GuardarArchivo($materiaJson, "Materia.txt", $materia); 
                }
                else
                {
                    echo "Falta definir algunos paràmetros";
                }
                break;

            case "inscribirAlumno":
                $nombre;
                $apellido;
                $email;
                $materia;
                $codigo;
                if(isset($_GET["nombre"]) && isset($_GET["apellido"]) && isset($_GET["email"])
                && isset($_GET["codigo"]) && isset($_GET["materia"]))
                {
                    $nombre = $_GET["nombre"];
                    $apellido = $_GET["apellido"];
                    $email = $_GET["email"];
                    $codigo = $_GET["codigo"];
                    $materia = $_GET["materia"];
                   // $inscripcion = new inscripcion($nombre, $apellido, $email, $codigo, $materia);
                    echo inscripcionArchivero::InscribirAlumno($nombre, $apellido, $email, $codigo, $materia, "Inscripciones.txt");
                }
                else
                {
                    echo "Falta definir algunos paràmetros";
                }
                break;
        }
    }
    else
    {
        echo "Falta definir el parametro CASO";
    }
}
?>