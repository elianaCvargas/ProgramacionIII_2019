<?php
include_once "personaDAO.php";
include_once "alumno.php";
class Archivero
{
    //alumno es json
    public static $lineaAObjeto = [];
    public static $encontrados = [];

    public static function GuardarArchivo($alumno, $path, $persona)
    {
        
        if(file_exists($path))
        {
            //Leo 
            $archivoLectura = fopen($path, "r");
            while(!feof($archivoLectura))
            {
                $linea = fgets($archivoLectura);
                archivero::$lineaAObjeto = json_decode($linea); 
            }
            fclose($archivoLectura);

           
            //Escribo
            $archivoEscritura = fopen($path, "w");
            array_push(archivero::$lineaAObjeto, $alumno);
            $objetoAjson = json_encode(archivero::$lineaAObjeto);
            fwrite($archivoEscritura, $objetoAjson);
            fclose($archivoEscritura);
            return "Se agregaron los datos:\n".$persona->Mostrar();
        }
        else
        {
            //Abro escritura: escribo solo el array  vacío
            $archivo = fopen($path, "w");
            $emptyArray = [];
            array_push($emptyArray, $alumno);
            var_dump($emptyArray);
            $encodedArray = json_encode($emptyArray);
            fwrite($archivo, $encodedArray);
            fclose($archivo);    
            
            //var_dump($persona);        
            return "Se generó el archivo...\n".$persona->Mostrar();   
        }
    }

    public function LeerArchivo($path)
    {

        if(file_exists($path))
        {
            //Leo 
            $archivoLectura = fopen($path, "r");
            while(!feof($archivoLectura))
            {
                $linea = fgets($archivoLectura);
                $lineaAObjeto = json_decode($linea); 
            }
           
            fclose($archivoLectura); 
            return $lineaAObjeto;          
        }
        else
        {
            return "no se encuentra el  archivo...";
        }
    }

    public static function MostrarEncontrados($dato, $path)
    {
        $datoMinuscula = strtolower($dato);

        $allAlumnos = archivero::LeerArchivo($path);
        $alumnosEncontrados = [];
var_dump($allAlumnos);
        //pregunto si existe alumno
        foreach($allAlumnos as $alumno)
        {
            $miAlumno = json_decode($alumno);
            $apellidoMinuscula = strtolower($miAlumno->apellido);
            if($apellidoMinuscula == $datoMinuscula)
            {
                 array_push($alumnosEncontrados, $miAlumno);
            }           
        }

        //$miAlumno->Mostrar()."\n"
        if(count($alumnosEncontrados) > 0)
        {
            foreach($alumnosEncontrados as $alu)
            {
                $alumno = new  Alumno($alu->nombre, $alu->apellido, $alu->email, $alu->imagen);
                echo $alumno->Mostrar()."\n";               
            }
        }
        else
        {
            return "No existe alumno con apellido ".$dato;;
        }
    }
}

?>