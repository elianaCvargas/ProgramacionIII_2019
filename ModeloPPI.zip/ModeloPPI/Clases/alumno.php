<?php
    include "persona.php";
    class Alumno extends Persona{
    
        private $id = 0;
        public $idString;
        public $email;
        //public $cuatrimestre;
        public $imagen;

       function __construct($nombre, $apellido, $email, $imagen)
       {
            parent::__construct($nombre, $apellido);
            $this->apellido = $apellido;
            $this->nombre = $nombre;
            $this->email = $email;
            $this->imagen = $imagen;
             $this->id += 1;
             $this->setIdString($this->id);
       }

       public function getEmail()
       {
            return $this->email;
       }
    
       public function setEmail($email)
       {
           $this->email = $email;
       }

       public function getId()
       {
            return $this->id;
       }
    
       public function setIdString($id)
       {
           $this->idString = $id."";
       }

       public function setId($id)
       {
           $this->id = $id + 1;
       }

       public function Mostrar()
       {
           //return parent::Mostrar().$this->email.$this->cuatrimestre; 
            return json_encode($this);
       }
        	
    }
?>