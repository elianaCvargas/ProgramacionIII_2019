<?php
include_once "personaDAO.php";
include_once "materia.php";
include_once "materiaArchivero.php";

class MateriaArchivero
{
    //alumno es json
    public static $lineaAObjeto = [];
    public static $encontrados = [];

    public static function GuardarArchivo($materiaJson, $path, $materia)
    {
        if(file_exists($path))
        {
            //obtengo array de json
            materiaArchivero::$encontrados = materiaArchivero::LeerArchivo($path);
            array_push(materiaArchivero::$lineaAObjeto, materiaArchivero::$encontrados);
            $lastElement = end(materiaArchivero::$encontrados);
            $decodedMateria = json_decode($lastElement);
            $idActual = (int)$decodedMateria->codigoString;
            $materia->setId($idActual);
            $materia->setCodigoString($materia->getId());
            $miMateriaJson = json_encode($materia);
            array_push(materiaArchivero::$encontrados, $miMateriaJson);
            //Escribo
            $archivoEscritura = fopen($path, "w");
            $objetoAjson = json_encode(materiaArchivero::$encontrados);
            fwrite($archivoEscritura, $objetoAjson);
            fclose($archivoEscritura);
             return "Se agregaron los datos:\n".$materia->Mostrar();
        }
        else
        {
            //Abro escritura: escribo solo el array  vacío
            $materia->setId(0);
            $materia->setCodigoString($materia->getId());
            $archivo = fopen($path, "w");
            $emptyArray = [];
            array_push($emptyArray, $materiaJson);
            $encodedArray = json_encode($emptyArray);
            fwrite($archivo, $encodedArray);
            fclose($archivo);    
            
            //var_dump($persona);        
            return "Se generó el archivo...\n".$materia->Mostrar();   
        }
    }

    public function LeerArchivo($path)
    {

        if(file_exists($path))
        {
            //Leo 
            $archivoLectura = fopen($path, "r");
            while(!feof($archivoLectura))
            {
                $linea = fgets($archivoLectura);
                $lineaAObjeto = json_decode($linea); 
            }
           
            fclose($archivoLectura); 
            return $lineaAObjeto;          
        }
        else
        {
            return "no se encuentra el  archivo...";
        }
    }

    public static function MostrarEncontrados($dato, $path)
    {
        $datoMinuscula = strtolower($dato);

        $allAlumnos = archivero::LeerArchivo($path);
        $alumnosEncontrados = [];

        //pregunto si existe alumno
        foreach($allAlumnos as $alumno)
        {
            $miAlumno = json_decode($alumno);
            $apellidoMinuscula = strtolower($miAlumno->apellido);
            if($apellidoMinuscula == $datoMinuscula)
            {
                 array_push($alumnosEncontrados, $miAlumno);
            }           
        }

        //$miAlumno->Mostrar()."\n"
        if(count($alumnosEncontrados) > 0)
        {
            foreach($alumnosEncontrados as $alu)
            {
                $alumno = new  Alumno($alu->nombre, $alu->apellido, $alu->email, $alu->imagen);
                echo $alumno->Mostrar()."\n";               
            }
        }
        else
        {
            return "No existe alumno con apellido ".$dato;;
        }
    }

    public static function Inscribir($dato, $path)
    {

    }

}

?>