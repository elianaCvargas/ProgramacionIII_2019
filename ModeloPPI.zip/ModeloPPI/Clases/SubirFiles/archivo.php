<?php

echo var_dump($_FILES);

$archivoTmpName = $_FILES["imagen"]["tmp_name"];
$extension = $_FILES["imagen"]["type"];

var_dump($archivoTmpName);
var_dump($extension);
//para saber si  un  usuario tiene una foto, verificar que tenga la extension.
//para obtener la extension podemos hacerlo con explode
$arrayNameImg = explode("/", $extension);
var_dump($arrayNameImg);
move_uploaded_file($archivoTmpName,"fileUploaded.php");
?>