<?php
include_once "personaDAO.php";
include_once "materia.php";
include_once "materiaArchivero.php";

class InscripcionArchivero
{
    //alumno es json
    public static $lineaAObjeto = [];
    public static $encontrados = [];

    public static function InscribirAlumno($nombre, $apellido, $email, $codigo, $materia, $path)
    {
        $materia =  inscripcionArchivero::BuscarMateriaYModificarCupo($materia, $codigo, "Materia.txt");
        if(count($materia) > 0)
        {
            $materia = array_shift($materia);
            $materiaDecoded = json_decode( $materia);
            
            
            if(file_exists($path))
            {
                
                //obtengo array de json
                inscripcionArchivero::$encontrados = inscripcionArchivero::LeerArchivo($path);
                
                var_dump( inscripcionArchivero::$encontrados);
                $inscripcion = new inscripcion($nombre, $apellido, $email, $materiaDecoded->codigoString, $materiaDecoded->nombre);
                $inscripcionJson = json_encode($inscripcion);
                array_push(inscripcionArchivero::$encontrados, $inscripcionJson);
                 //Escribo
                 $archivoEscritura = fopen($path, "w");
                 $objetoAjson = json_encode(inscripcionArchivero::$encontrados);
                 fwrite($archivoEscritura, $objetoAjson);
                 fclose($archivoEscritura);
                 return "Se agregaron los datos:\n".$inscripcion->Mostrar();
            }
            else
            {
                //Abro escritura: escribo solo el array  vacío
                $cupo = (int)$materiaDecoded->cupo;
                
                if($cupo > 0)
                {
                    $inscripcion = new inscripcion($nombre, $apellido, $email, $materiaDecoded->codigoString, $materiaDecoded->nombre);
                    $inscripcionJson = json_encode($inscripcion);
                    $archivo = fopen($path, "w");
                    $emptyArray = [];
                    array_push($emptyArray, $inscripcionJson);
                  
                    $encodedArray = json_encode($emptyArray);
                    fwrite($archivo, $encodedArray);
                    fclose($archivo);  
                    return "Se generó el archivo...\n Inscripcion a materia: ".$inscripcion->Mostrar();  
                }
                else
                {

                    return "No queda mas cupo para la materia ".$materiaDecoded->nombre;  
                }

                 
            }
        }
        else
        {
            echo "no se pudo inscribir, materia inexistente";  
        }  
    }

    public function LeerArchivo($path)
    {

        if(file_exists($path))
        {
            //Leo 
            $archivoLectura = fopen($path, "r");
            while(!feof($archivoLectura))
            {
                $linea = fgets($archivoLectura);
                inscripcionArchivero::$lineaAObjeto = json_decode($linea);
            }
           
            fclose($archivoLectura); 
            return inscripcionArchivero::$lineaAObjeto;          
        }
        else
        {
            return "no se encuentra el  archivo...";
        }
    }

    public static function BuscarMateriaYModificarCupo($materia,$codigo, $path)
    {
        $datoMinuscula = strtolower($materia);
        $allMaterias = inscripcionArchivero::LeerArchivo($path);
        
        $materiasEncontrados = [];        
        $materiaEncontrada = [];

        foreach($allMaterias as $mate)
        {
            $miMateria = json_decode($mate);
            $materiaMinuscula = strtolower($miMateria->nombre);
            if($materiaMinuscula == $datoMinuscula && $miMateria->codigoString == $codigo)
            {
                $materiaObj = new Materia($miMateria->nombre, $miMateria->cupo, $miMateria->aula);
                $materiaObj->setCodigoString($miMateria->codigoString);
                $materiaObj->setCupo($miMateria->cupo);
                $materiaModificado = json_encode($materiaObj);
                 
                array_push($materiasEncontrados, $materiaModificado);
                array_push($materiaEncontrada, $materiaModificado);
            }      
            else
            {
                array_push($materiasEncontrados, $mate);
            }     
        }

        //guardo encontrados
        if(count($materiaEncontrada) > 0)
        {
            $archivoEscritura = fopen($path, "w");
            $objetoAjson = json_encode($materiasEncontrados);
            fwrite($archivoEscritura, $objetoAjson);
            fclose($archivoEscritura);

            return $materiaEncontrada;
        }
        else
        {
            return $materiaEncontrada;
        }
    }

    public static function Inscribir($dato, $path)
    {

    }

}

?>