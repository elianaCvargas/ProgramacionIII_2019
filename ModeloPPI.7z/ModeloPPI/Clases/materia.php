<?php
    class Materia 
    {
        public $nombre;
        public $codigo;
        public $cupo;
        public $aula;

       function __construct($nombre, $codigo, $cupo, $aula)
       {
            $this->codigo = $codigo;
            $this->nombre = $nombre;
            $this->cupo = $cupo;
            $this->aula = $aula;
       }

       public function getcupo()
       {
            return $this->cupo;
       }
    
       public function setcupo($cupo)
       {
           $this->cupo = $cupo;
       }

       public function Mostrar()
       {
           return parent::Mostrar().$this->cupo.$this->cuatrimestre; 
       }
        	
    }
?>