<?php
    include "persona.php";
    class Alumno extends Persona{
    
        public $email;
        public $cuatrimestre;
        public $imagen;

       function __construct($nombre, $apellido, $email, $imagen)
       {
            parent::__construct($nombre, $apellido);
            $this->apellido = $apellido;
            $this->nombre = $nombre;
            $this->email = $email;
            $this->imagen = $imagen;
       }

       public function getEmail()
       {
            return $this->email;
       }
    
       public function setEmail($email)
       {
           $this->email = $email;
       }

       public function Mostrar()
       {
           return parent::Mostrar().$this->email.$this->cuatrimestre; 
       }
        	
    }
?>