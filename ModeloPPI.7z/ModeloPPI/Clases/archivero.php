<?php
include_once "personaDAO.php";
include_once "alumno.php";
class Archivero
{
    //alumno es json
    public static function GuardarArchivo($alumno, $path)
    {
        $lineaAObjeto = [];
        if(file_exists($path))
        {
            //Leo 
            $archivoLectura = fopen($path, "r");
            while(!feof($archivoLectura))
            {
                $linea = fgets($archivoLectura);
                $lineaAObjeto = json_decode($linea); 
            }
            fclose($archivoLectura);

            //Escribo
            $archivoEscritura = fopen($path, "w");
            array_push($lineaAObjeto, $alumno);
            $objetoAjson = json_encode($lineaAObjeto);
            fwrite($archivoEscritura, $objetoAjson);
            echo "Se agregaron los datos";
            fclose($archivoEscritura);
        }
        else
        {
            //Abro escritura: escribo solo el array  vacío
            $archivo = fopen($path, "w");
            $emptyArray = [];
            array_push($emptyArray, $alumno);
            $encodedArray = json_encode($emptyArray);
            fwrite($archivo, $encodedArray);
            echo "Se generó el archivo";
            fclose($archivo);   
        }
        
    }

    public static function LeerArchivo($apellido, $path)
    {
        $lineaAObjeto = [];
        $encontrados = [];
        if(file_exists($path))
        {
            //Leo 
            $archivoLectura = fopen($path, "r");
            while(!feof($archivoLectura))
            {
                $linea = fgets($archivoLectura);
                $lineaAObjeto = json_decode($linea); 
            }
            fclose($archivoLectura);
            foreach($lineaAObjeto as $arrayObj)
            {
                $miObj = json_decode($arrayObj);
                if($miObj->apellido == $apellido)
                {
                    array_push($encontrados, $miObj);
                }
            }

            if(count($encontrados) > 0)
            {
                var_dump($encontrados);
            }
            else
            {
                echo "No existe alumno con apellido ".$apellido;
            }
        }
        else
        {
            echo "no se encuentra el  archivo...";
        }
        
    }
}

?>