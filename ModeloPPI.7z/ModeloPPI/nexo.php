<?php
include "Clases/alumno.php";
include "Clases/personaDAO.php";
include "Clases/archivero.php";
include "Clases/materia.php";

if($_SERVER["REQUEST_METHOD"] == "POST")
{
    if(isset($_POST["caso"]))
    {
        switch($_POST["caso"])
        {
            case "cargarAlumno":
            echo "Cargo alumno...\n";
            $nombre;
            $apellido;
            $email;
            $foto;
            if(isset($_POST["nombre"]) && isset($_POST["apellido"]) 
            && isset($_POST["email"]) && isset($_FILES["foto"]))
            {
                //$nombre, $dni, $legajo, $cuatrimestre, $id, imagen
                //verificar que no sea el  mismo alumno antes de agregar
                $nombre = $_POST["nombre"];
                $apellido = $_POST["apellido"];
                $email = $_POST["email"];
                $foto = $_FILES["foto"];
                $persona = new Alumno($nombre, $apellido, $email, $foto);
                personaDAO::Guardar($persona);//esto es un array
                $alumnoJson = json_encode($persona);
                archivero::GuardarArchivo($alumnoJson, "Alumno.txt"); 
                //devolver el mensaje json  de si se pudo cargar o no
                //el jsn de la persona que se agrego
            }
            else
            {
                echo "Falta definir algunos paràmetros";
            }
            break;
            case "consultarAlumno":
            echo "Consultando...";
            if(isset($_GET["apellido"]))
            {
                archivero::LeerArchivo($_GET["apellido"], "Alumno.txt");
            }
            else
            {
                echo "no se está definido el filtro de búsqueda";
            }
            break;
            case "cargarMateria":
            $nombre;
            $codigo;
            $cupo;
            $aula;
            if(isset($_POST["nombre"]) && isset($_POST["codigo"]) 
            && isset($_POST["cupo"]) && isset($_POST["aula"]))
            {
                $nombre = $_POST["nombre"];
                $codigo = $_POST["codigo"];
                $cupo = $_POST["cupo"];
                $aula = $_POST["aula"];
                $materia = new Materia($nombre, $codigo, $cupo, $aula);
                $materiaJson = json_encode($materia);
                archivero::GuardarArchivo($materia, "Materia.txt"); 
            }
            else
            {
                echo "Falta definir algunos paràmetros";
            }
            break;
            case "inscribirAlumno":
            $nombre;
            $apellido;
            $email;
            $materia;
            $codigo;
            if(isset($_POST["nombre"]) && isset($_POST["apellido"]) && isset($_POST["email"])
            && isset($_POST["codigo"]) && isset($_POST["materia"]))
            {
                $nombre = $_POST["nombre"];
                $apellido = $_POST["apellido"];
                $email = $_POST["email"];
                $codigo = $_POST["codigo"];
                $materia = $_POST["materia"];
                 
            }
            else
            {
                echo "Falta definir algunos paràmetros";
            }
            break;
        }
    }
    else
    {
        echo "Falta definir el parametro CASO";
    }
}
?>