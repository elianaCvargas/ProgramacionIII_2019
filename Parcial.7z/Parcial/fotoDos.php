{
  "directory": "bower_components"
}
