<?php
    include "persona.php";
    class Usuario 
    {
        public $nombre;
        private $id = 0;
        public $legajo;
        public $email;
        public $clave;
        public $fotoUno;
        public $fotoDos;

       function __construct($nombre, $email, $clave, $fotoUno, $fotoDos)
       {
            $this->nombre = $nombre;
            $this->email = $email;
            $this->clave = $clave;
            $this->fotoUno = $fotoUno;
            $this->fotoDos = $fotoDos;
       }

       public function getemail()
       {
            return $this->email;
       }
    
       public function setemail($email)
       {
           $this->email = $email - 1;
       }

       public function getId()
       {
            return $this->id;
       }
    
       public function setId($idActual)
       {
           $this->id = $idActual + 1;
       }

       public function getCodigoString()
       {
            return $this->legajo;
       }
    
       public function setCodigoString($legajo)
       {
            $this->legajo = $legajo."";
       }

       public function Mostrar()
       {
            return json_encode($this); 
       }
        	
    }
?>