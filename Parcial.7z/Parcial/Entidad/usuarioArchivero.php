<?php
// include_once "personaDAO.php";
// include_once "materia.php";
// include_once "usuarioArchivero.php";

class UsuarioArchivero
{
    //alumno es json
    public static $lineaAObjeto = [];
    public static $encontrados = [];

    public static function GuardarArchivo($usuarioJason, $path, $usuario)
    {
        if(file_exists($path))
        {
            //obtengo array de json
            usuarioArchivero::$encontrados = usuarioArchivero::LeerArchivo($path);
            array_push(usuarioArchivero::$lineaAObjeto, usuarioArchivero::$encontrados);
            $lastElement = end(usuarioArchivero::$encontrados);
            $decodedUsuario = json_decode($lastElement);
            $idActual = (int)$decodedUsuario->legajo;
            $usuario->setId($idActual);
            $usuario->setCodigoString($usuario->getId());
            $miusuarioJason = json_encode($usuario);
            array_push(usuarioArchivero::$encontrados, $miusuarioJason);
            //Escribo
            $archivoEscritura = fopen($path, "w");
            $objetoAjson = json_encode(usuarioArchivero::$encontrados);
            fwrite($archivoEscritura, $objetoAjson);
            fclose($archivoEscritura);
             return "Se agregaron los datos:\n".$usuario->Mostrar();
        }
        else
        {
            //Abro escritura: escribo solo el array  vacío
            $usuario->setId(0);
            $usuario->setCodigoString($usuario->getId());
            $archivo = fopen($path, "w");
            $emptyArray = [];
            array_push($emptyArray, $usuarioJason);
            $encodedArray = json_encode($emptyArray);
            fwrite($archivo, $encodedArray);
            fclose($archivo);    
            
            //var_dump($persona);        
            return "Se generó el archivo...\n".$usuario->Mostrar();   
        }
    }

    public function LeerArchivo($path)
    {

        if(file_exists($path))
        {
            //Leo 
            $archivoLectura = fopen($path, "r");
            while(!feof($archivoLectura))
            {
                $linea = fgets($archivoLectura);
                $lineaAObjeto = json_decode($linea); 
            }
           
            fclose($archivoLectura); 
            return $lineaAObjeto;          
        }
        else
        {
            return "no se encuentra el  archivo...";
        }
    }

    public static function MostrarEncontrados($dato, $clave, $path)
    {

        $datoMinuscula = strtolower($dato);
        $claveMinuscula = strtolower($clave);

        $allUsuarios = usuarioArchivero::LeerArchivo($path);

        $usuariosEncontrados = [];
        foreach($allUsuarios as $usuario)
        {
            $miusuario = json_decode($usuario);
            
            $legajoMinuscula = strtolower($miusuario->legajo);
            $claveMin = strtolower($miusuario->clave);

            if($legajoMinuscula == $datoMinuscula && $claveMin == $claveMinuscula)
            {
                 array_push($usuariosEncontrados, $miusuario);
            }           
        }
        if(count($usuariosEncontrados) > 0)
        {
            foreach($usuariosEncontrados as $alu)
            {
                $usuario = new  Usuario($alu->nombre, $alu->email, $alu->clave, $alu->fotoUno, $alu->fotoDos);
                $usuario->legajo = $alu->legajo;
                echo $usuario->Mostrar()."\n";               
            }
        }
        else
        {
            return "No existe usuario que coincida con el legajo ".$dato;;
        }
    }

    public static function BuscarYModificarUsuario($nombre, $email, $clave, $path)
    {
        $nombreU = strtolower($nombre);
        $emailU = strtolower($email);
        $claveU = strtolower($clave);

        $allUsuarios = inscripcionArchivero::LeerArchivo($path);
        
        $materiasEncontrados = [];        
        $materiaEncontrada = [];

        foreach($allUsuarios as $mate)
        {
            $miUsuario = json_decode($mate);
            $nombreMin = strtolower($miUsuario->nombre);
            $emailMin = strtolower($miUsuario->email);
            $claveMin = strtolower($miUsuario->clave);

            if($materiaMinuscula == $datoMinuscula && $miUsuario->codigoString == $codigo)
            {
                $materiaObj = new Materia($miUsuario->nombre, $miUsuario->cupo, $miUsuario->aula);
                $materiaObj->setCodigoString($miUsuario->codigoString);
                $materiaObj->setCupo($miUsuario->cupo);
                $materiaModificado = json_encode($materiaObj);
                 
                array_push($materiasEncontrados, $materiaModificado);
                array_push($materiaEncontrada, $materiaModificado);
            }      
            else
            {
                array_push($materiasEncontrados, $mate);
            }     
        }

        //guardo encontrados
        if(count($materiaEncontrada) > 0)
        {
            $archivoEscritura = fopen($path, "w");
            $objetoAjson = json_encode($materiasEncontrados);
            fwrite($archivoEscritura, $objetoAjson);
            fclose($archivoEscritura);

            return $materiaEncontrada;
        }
        else
        {
            return $materiaEncontrada;
        }
    }

}

?>