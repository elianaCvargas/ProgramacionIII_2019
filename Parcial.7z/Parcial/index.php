<?php
include "Entidad/usuario.php";
include "Entidad/usuarioArchivero.php";


if($_SERVER["REQUEST_METHOD"] == "POST")
{
    if(isset($_POST["caso"]))
    {
        switch($_POST["caso"])
        {
            case "cargarUsuario":
               
                $nombre;
                $clave;
                $email;
                $fotoUno;
                $fotoDos;
                if(isset($_POST["nombre"]) && isset($_POST["clave"]) 
                && isset($_POST["email"]) && isset($_FILES["fotoUno"]) && isset($_FILES["fotoDos"]))
                {

                   
                    $nombre = $_POST["nombre"];               
                    $email = $_POST["email"];
                    $clave = $_POST["clave"];
                    $fotoUno = $_FILES["fotoUno"]["name"];
                    $fotoDos = $_FILES["fotoDos"]["name"];
                    $extension = $_FILES["fotoUno"]["type"];
                    
                    $arrayNameImgUno = explode("/", $extension);
                   
                    $extension2 = $_FILES["fotoDos"]["type"];
                    $arrayNameImg2 = explode("/", $extension2);

                    $archivoTmpName = $_FILES["fotoUno"]["tmp_name"];
                    $archivoTmpNameDos = $_FILES["fotoDos"]["tmp_name"];
                    
                    move_uploaded_file($archivoTmpName,"fotoUno.".$arrayNameImgUno[1]);
                    move_uploaded_file($archivoTmpNameDos,"fotoDos.".$arrayNameImg2[1]);
                    //$nombre, $email, $clave, $fotoUno, $fotoDos
                    $usuario = new Usuario($nombre, $email, $clave, $fotoUno, $fotoDos);
                    //var_dump($usuario);
                    $usuario->setId(0);
                    $usuario->setCodigoString($usuario->getId());
                    $usuarioJson = json_encode($usuario);
                    echo usuarioArchivero::GuardarArchivo($usuarioJson, "Usuario.txt", $usuario); 
                }
                else
                {
                    echo "Falta definir algunos paràmetros para cargar el  alumno";
                }
                break;

            case "login":
                echo "Consultando...\n";
                if(isset($_GET["legajo"]) && isset($_GET["clave"]) )
                {
                    echo usuarioArchivero::MostrarEncontrados($_GET["legajo"],$_GET["clave"], "Usuario.txt");
                }
                else
                {
                    echo "no se está definido el filtro de búsqueda";
                }
                break;
            case "modificarUsuario":
                $nombre;
                $email;
                $clave;
                
                $usuario = new Usuario($nombre, $email, $clave, $fotoUno, $fotoDos);

                if(isset($_GET["nombre"]) && isset($_GET["email"]) && isset($_GET["clave"]))
                {
                    $nombre = $_GET["nombre"];
                    $email = $_GET["email"];
                    $codigo = $_GET["clave"];
                   // $inscripcion = new inscripcion($nombre, $apellido, $email, $codigo, $materia);
                    echo usuarioArchivero::BuscarYModificarUsuario($nombre, $email, $clave, "Usuario.txt");
                }
                else
                {
                    echo "Falta definir algunos paràmetros";
                }
                break;
        }
    }
    else
    {
        echo "Falta definir el parametro CASO";
    }
}
?>