<?php
include "Clases/archivero.php";
class cdApi
{
    
    // public $alumnoController;

    // public function __construct()
    // {
    //     $this->alumnoController = new AlumnoController();
    // }

    // public function traerTodos($request, $response, $args){ 
    //     $alumnos = $this->alumnoController->mostrarAlumnos();
    //     return $response->getbody()->write($alumnos);
    // }
    
    public function traerUno($request, $response, $args){ 
        $tipo = $args['tipo'];
        $sabor = $args['sabor'];

        $pizz = archivero::BuscarUnoPorClaveInsensityveCase("tipo", $sabor, "Pizza.txt");
        return $response->getbody()->write(json_encode($alumno));
    }

    public function cargarUno($request, $response, $args){
        $arrayDeParametros = $request->getParsedBody();
        $tipo = $arrayDeParametros['tipo'];
        $sabor = $arrayDeParametros['sabor'];
        $cantidad = $arrayDeParametros['cantidad'];
        $precio = $arrayDeParametros['precio'];       
        $archivos = $request->getUploadedFiles();        
        $imagen1 = $archivos['imagen1'];
        $imagen2 = $archivos['imagen2'];

         $tmpName = $imagen1->getClientFilename(); //obtiene el tipo temporal de la foto recibida por parametro
         $extension = pathInfo($tmpName, PATHINFO_EXTENSION); // obtiene la extencion de la foto recibida por parametro
         $fotoName1 = "./images/pizzas/" . $tipo . "." . $extension; //se crea el filename

         $tmpName2 = $imagen2->getClientFilename(); //obtiene el tipo temporal de la foto recibida por parametro
         $extension2 = pathInfo($tmpName2, PATHINFO_EXTENSION); // obtiene la extencion de la foto recibida por parametro
         $fotoName2 = "./images/pizzas/" . $sabor . "." . $extension; //se crea el filename
        $pizza = new Pizza($tipo, $sabor, $cantidad, $precio, $imagen1, $imagen2);
        $id = archivero::ObtenerUltimoId("Pizza.txt") > 0 ? archivero::ObtenerUltimoId("Pizza.txt") : 1;
        $pizza->id = $id;
        $pizzaJson = $pizza->ToJson(); 

        $pizz = archivero::BuscarUnoPorClaveInsensityveCase("tipo", $sabor, "Pizza.txt");  
             
        if($pizz == null)
        {
             $imagen1->moveTo($fotoName1);
             $imagen2->moveTo($fotoName2);  
             $seCreoArchivo = archivero::GuardarArchivo($pizzaJson, "Pizza.txt");                    
             $mensaje = $seCreoArchivo ? "Se generó el archivo...\n".$pizza->Mostrar() : "Se agregaron los datos:\n".$persona->Mostrar();    
             return $response->getbody()->write($mensaje);
        }
        else{
            return "El Pizza ya existe";
        }
    }

    public function modificarUno($request, $response, $args){ 
        $rta = false;
       
        $parametros = $request->getParsedBody();
        $archivos = $request->getUploadedFiles();

        // var_dump($archivos);
        var_dump($parametros);

        $alumnoAModificar = archivero::BuscarUnoPorClaveInsensityveCase("email", $parametros["email"], "Alumno.txt");  
        //var_dump($alu);
        //puede ir en un controller
        if(!is_null($alumnoAModificar))
        {
            $rta == true;
                /// Me guardo el valor actual de todas la claves del usuario, si el usuario deseará modificarlas, se pisaran.
                $nombreAux = $alumnoAModificar->nombre;
                $apellidoAux = $alumnoAModificar->apellido;
                $fotoAux = $alumnoAModificar->imagen;
                $idAux = $alumnoAModificar->id;

                //pregunta si en el POST que se recibio por parametro contiene la key "apellido" para verificar si es lo que se quiere modificar y ademas pregunta si el apellido del alumno obtenido por email es distinto del apellido que hay en el POST
                if (array_key_exists("apellido", $parametros) && $apellidoAux != $parametros["apellido"]) { 
                    $apellidoAux = $parametros["apellido"]; //pisa el apellido del alumno obtenido con el apellido recibido en POST
                }
                //pregunta si en el POST que se recibio por parametro contiene la key "nombre" para verificar si es lo que se quiere modificar y ademas pregunta si el nombre del alumno obtenido por email es distinto del nombre que hay en el POST
                if (array_key_exists("nombre", $parametros) && $nombreAux != $parametros["nombre"]) {
                    $nombreAux = $parametros["nombre"];//pisa el nombre del alumno obtenido con el nombre recibido en POST
                }
                if (array_key_exists("foto", $archivos)) {
                    $fechaBkp = date("d-m-Y_H_i");// Me guardo la hora actual
                    $array = explode(".", $alumnoAModificar->foto); //transformo en un array todo lo que este separado por un punto
                    $rutaParaBkp = "./imagenes/backUpFotos/" . 
                    $alumnoAModificar->apellido . $fechaBkp . "." . end($array);//Genero la ruta para almacenar la foto de backup
                    //Backup Imagen
                    rename($alumnoAModificar->foto, $rutaParaBkp);// Hago backup de la foto
                    //Modificacion
                    $tmpName = $foto->getClientFilename();
                    $extension = pathinfo($tmpName, PATHINFO_EXTENSION);
                    $fotoAux = "./imagenes/" . $parametros["email"] . "." . $extension; // Cambio el nombre de la foto y coloco email.extension
                    $foto->moveTo($fotoAux);
                } 
                $alumnoAux = new Alumno($nombreAux, $apellidoAux, $parametros["email"], $fotoAux); //se crea un nuevo alumno con los datos ya modificados
                $alumnoAux->id = $idAux;
// var_dump($alumnoAux->id );
                $rta = archivero::modificarUno("email", $parametros["email"], "Alumno.txt", $alumnoAux);
                if($rta)
                {
                    echo "Modificacion realizada";
                }
                else{
                    echo "No se pudo realizar la modificacion";
                }
        }
        else{
            echo "No se encontro el alumno";
        }
        
        
    }

    public function borrarUno($request, $response, $args){ 
        return $response->getbody()->write("Hello world DELETE");
    }


}