<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './vendor/autoload.php';
require_once './Clases/pizza.php';
require_once './cdApi.php';


$config ['displayErrorDetails'] = true;
$config ['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings" => $config]);

$app->group('/pizza', function() 
{
    $this->get('/', cdApi::class . ':traerTodos');

    $this->get('/{tipo}', cdApi::class . ':traerUno');

    $this->post('/', cdApi::class . ':cargarUno');
    
    $this->put('/', cdApi::class . ':modificarUno');
    
    $this->delete('/', cdApi::class . ':borrarUno');

});

$app -> run();


