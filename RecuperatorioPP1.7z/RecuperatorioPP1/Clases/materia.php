<?php
    class Materia 
    {
        public $nombre;
        public $id;
        public $cupo;
        public $aula;

       function __construct($nombre, $cupo, $aula)
       {
            $this->nombre = $nombre;
            $this->cupo = $cupo;
            $this->aula = $aula;
       }

       public function getcupo()
       {
            return $this->cupo;
       }
    
       public function setcupo($cupo)
       {
           $this->cupo = $cupo - 1;
       }

       public function getId()
       {
            return $this->id;
       }
    
       public function setId($idActual)
       {
           $this->id = $idActual + 1;
       }

       public function getCodigoString()
       {
            return $this->codigoString;
       }
    
       public function setCodigoString($codigo)
       {
            $this->codigoString = $codigo."";
       }

       public function Mostrar()
       {
            return json_encode($this); 
       }
     
       public function ToJson()
       {
            $jsonString = json_encode($this);
            return json_decode($jsonString);
       }
    }
?>