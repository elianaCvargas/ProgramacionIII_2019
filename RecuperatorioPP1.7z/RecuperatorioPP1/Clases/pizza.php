<?php
    class Pizza  {
        public $id;
        public $tipo;
        public $sabor;
        public $cantidad;
        public $precio;
        public $imagen1;
        public $imagen2;

       function __construct($tipo,$sabor, $cantidad, $precio, $imagen1, $imagen2)
       {
            $this->cantidad = $cantidad;
            $this->tipo = $tipo;
            $this->precio = $precio;
            $this->imagen1 = $imagen1;
            $this->imagen2 = $imagen2;
            $this->sabor = $sabor;

       }

       public function getprecio()
       {
            return $this->precio;
       }
    
       public function setprecio($precio)
       {
           $this->precio = $precio;
       }

       public function getId()
       {
            return $this->id;
       }
    
       public function setIdString($id)
       {
           $this->idString = $id."";
       }

       public function setId($id)
       {
           $this->id = $id + 1;
       }

       public function Mostrar()
       {
           
            return json_encode($this);
       }
       public function ToJson()
       {
            $jsonString = json_encode($this);
            return json_decode($jsonString);
       }	
    }
?>