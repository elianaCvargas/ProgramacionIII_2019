<?php
    include "persona.php";
    class Alumno extends Persona{
    
        public $id;
        public $email;
        //public $cuatrimestre;
        public $imagen;

       function __construct($nombre, $apellido, $email, $imagen)
       {
            parent::__construct($nombre, $apellido);
            $this->apellido = $apellido;
            $this->nombre = $nombre;
            $this->email = $email;
            $this->imagen = $imagen;
       }

       public function getEmail()
       {
            return $this->email;
       }
    
       public function setEmail($email)
       {
           $this->email = $email;
       }

       public function getId()
       {
            return $this->id;
       }
    
       public function setIdString($id)
       {
           $this->idString = $id."";
       }

       public function setId($id)
       {
           $this->id = $id + 1;
       }

       public function Mostrar()
       {
           
            return json_encode($this);
       }
       public function ToJson()
       {
            $jsonString = json_encode($this);
            return json_decode($jsonString);
       }	
    }
?>