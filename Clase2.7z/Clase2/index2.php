<?php
//escribir
 $archivo = fopen("file.txt", "a");
 $nombre = $_POST["nombre"];
 $apellido = $_POST["apellido"];
fwrite($archivo, $nombre.";".$apellido."\n");
 fclose($archivo);


 //leer
 $arch2 = fopen("file.txt", "r");
while(!feof($arch2))
{
    $linea = fgets($arch2);
    $ex = explode(";", $linea);
    var_dump($ex);
    //luego convertirlo en un objeto
    foreach($ex as $item)
    {
        echo($item."\n");
    }
}
 fclose($arch2);
?>