<?php
include "Clases/alumno.php";
include "Clases/personaDAO.php";
include "Clases/archivero.php";

//  $persona = new Alumno("Geraldine", 37171723, 123, 2);
// $persona->saludar();
//echo "Hola";
// var_dump($_GET);

//var_dump($_SERVER["REQUEST_METHOD"]);
$info = array('café ', 'marrón ', 'cafeína ');

if($_SERVER["REQUEST_METHOD"] == "GET")
{
    foreach($info as $item)
    {
        echo $item; 
    }
}

if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $nombre;
    $apellido;
    $dni;
    $id;
    $legajo;
    $cuatrimestre;
    $imagen;
    if(isset($_POST["nombre"]) && isset($_POST["apellido"]) && isset($_POST["dni"]) && isset($_POST["legajo"]) && isset($_POST["cuatrimestre"]) && isset($_FILES["imagen"]))
    {
        //$nombre, $dni, $legajo, $cuatrimestre, $id, imagen
        //verificar que no sea el  mismo alumno antes de agregar
        
        $nombre = $_POST["nombre"];
        $apellido = $_POST["apellido"];
        $dni = $_POST["dni"];
        $legajo = $_POST["legajo"];
        $cuatrimestre = $_POST["cuatrimestre"];
        $imagen = $_FILES["imagen"];
        var_dump($imagen);
        $persona = new Alumno($nombre, $dni, $legajo, $cuatrimestre, $imagen);
        personaDAO::Guardar($persona);//esto es un array
        $alumnoJson = json_encode($persona);
        archivero::GuardarArchivo($alumnoJson); 
    }
    else
    {
        echo "Falta definir algunos paràmetros";
    }
}

// if($_SERVER["REQUEST_METHOD"] == "POST")
// {
//     if(isset($_POST["Fruta"]))
//     {
//         array_push($info, $_POST["Fruta"]);
//         foreach($info as $item)
//         {
//             echo $item; 
//         }
//     }
// }

?>