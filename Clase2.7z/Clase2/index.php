<?php
include "Clases/alumno.php";
 $persona = new Alumno("Geraldine", 37171723, 123, 2);
// $persona->saludar();
//echo "Hola";
// var_dump($_GET);

//var_dump($_SERVER["REQUEST_METHOD"]);
$info = array('café ', 'marrón ', 'cafeína ');

if($_SERVER["REQUEST_METHOD"] == "GET")
{
    foreach($info as $item)
    {
        echo $item; 
    }
}

if($_SERVER["REQUEST_METHOD"] == "POST")
{
    if(isset($_POST["Fruta"]))
    {
        array_push($info, $_POST["Fruta"]);
        foreach($info as $item)
        {
            echo $item; 
        }
    }
}

?>