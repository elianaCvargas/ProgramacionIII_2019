<?php
include_once "personaDAO.php";

class Archivero
{
    public static function GuardarArchivo($alumno)
    {
        $lineaAObjeto = [];
        if(file_exists("Alumno.txt"))
        {
            //Leo 
            $archivoLectura = fopen("Alumno.txt", "r");
            while(!feof($archivoLectura))
            {
                $linea = fgets($archivoLectura);
                $lineaAObjeto = json_decode($linea); 
            }
            fclose($archivoLectura);

            //Escribo
            $archivoEscritura = fopen("Alumno.txt", "w");
            array_push($lineaAObjeto, $alumno);
            $objetoAjson = json_encode($lineaAObjeto);
            fwrite($archivoEscritura, $objetoAjson);
            echo "Se agregaron los datos";
            fclose($archivoEscritura);
        }
        else
        {
            //Abro escritura: escribo solo el array  vacío
            $archivo = fopen("Alumno.txt", "w");
            $emptyArray = [];
            array_push($emptyArray, $alumno);
            $encodedArray = json_encode($emptyArray);
            fwrite($archivo, $encodedArray);
            echo "Se generó el archivo";
            fclose($archivo);   
        }
        
    }
}

?>