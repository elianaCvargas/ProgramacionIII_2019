<?php
include_once "personaDAO.php";
class Archivero
{
    public static function GuardarArchivo($alumnoJson)
    {
        if(file_exists("Alumno.txt"))
        {
            $archivo = fopen("Alumno.txt", "r");
            while(!feof($archivo))
            {
                $decoded = json_decode($archivo);
                var_dump($decoded);
            }
            //fwrite($archivo, $uselessJson);
            fclose($archivo);

        }
        else
        {
            $archivo = fopen("Alumno.txt", "w");
            $emptyArray = [];
            $uselessJson = json_encode($emptyArray);
            fwrite($archivo, $uselessJson);
            fclose($archivo);
           
            echo "Se genero el array  vacio\n";
        }
        
    }
}

?>