<?php 

class Persona
{
    private  $id;
    private $nombre;
    private $dni;
    
    public function __construct($nombre, $dni, $id){        

        $this->nombre = $nombre;
        $this->dni = $dni;
        $this->id = $id;
    }  

    public function getId()
    {
     return $this->id;   
    }

    public function setId($id)
    {
        $this->id = $id;
    }
    
    public function getNombre()
    {
     return $this->nombre;   
    }
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }
    
    public function getDni()
    {
     return $this->dni;   
    }
    public function setDni($dni)
    {
        $this->dni = $dni;
    }

    public function Mostrar(){
        return $this->id.$this->nombre.$this->dni;
    }

    
}

?>