<?php
    include "persona.php";
    class Alumno extends Persona{
    
        public $legajo;
        public $cuatrimestre;
        public $imagen;

       function __construct($nombre, $dni, $legajo, $cuatrimestre, $imagen)
       {
            parent::__construct($nombre, $dni);
            $this->dni = $dni;
            $this->nombre = $nombre;
            $this->legajo = $legajo;
            $this->cuatrimestre = $cuatrimestre;
            $this->imagen = $imagen;
           // $this->id = 0;
       }

       public function getLegajo()
       {
            return $this->legajo;
       }
    
       public function setLegajo($legajo)
       {
           $this->legajo = $legajo;
       }
       public function getCuatrimestre()
       {
            return $this->cuatrimestre;
       }
       public function setCuatrimestre($cuatrimestre)
       {
           $this->cuatrimestre = $cuatrimestre;
       }

       public function Mostrar()
       {
           return parent::Mostrar().$this->legajo.$this->cuatrimestre; 
       }
        	
    }
?>