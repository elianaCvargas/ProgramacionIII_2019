<?php 
include "alumno.php";
class personaDAO
{
    public $alumnos = [];


    
    public function Guardar($alumno)
    {
        array_push($alumno);
    }

    public function Borrar($idAlumno)
    {
        if(count($alumnos) > 0)
        {
            foreach($alumno as $item)
            {
                if($item->getId() == $idAlumno)
                {
                    unset($item);
                }
            }

        }
    }

    public function modificar($alumno, $idAlumno)
    {
        if(count($alumnos) > 0)
        {
            foreach($alumno as $item)
            {
                if($item->getId() == $idAlumno)
                {
                   $item->nombre = $alumno->nombre;
                   $item->dni = $alumno->dni;
                   $item->legajo = $alumno->legajo;
                   $item->cuatrimestre = $alumno->cuatrimestre;
                }
            }

        }
    }

    public function ListarAlumnos()
    {
        if(count($alumnos) > 0)
        {
            foreach($alumno as $item)
            {
                parent::$this->getNombre();
            }

        }
    }
    
}

?>