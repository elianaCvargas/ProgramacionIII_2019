<?php 
include_once "alumno.php";
class personaDAO
{
    public static  $alumnos = [];


    
    public static function Guardar($alu)
    {
        array_push(personaDAO::$alumnos, $alu);
    }

    public function Borrar($idAlumno)
    {
        if(count($alumnos) > 0)
        {
            foreach($alumno as $item)
            {
                if($item->getId() == $idAlumno)
                {
                    unset($item);
                }
            }

        }
    }

    public function modificar($alu, $idAlumno)
    {
        if(count($alumnos) > 0)
        {
            foreach($alumno as $item)
            {
                if($item->getId() == $idAlumno)
                {
                   $item->nombre = $alumno->nombre;
                   $item->dni = $alumno->dni;
                   $item->legajo = $alumno->legajo;
                   $item->cuatrimestre = $alumno->cuatrimestre;
                }
            }

        }
    }

    public function ListarAlumnos()
    {
        if(count($alumnos) > 0)
        {
            foreach($alumno as $item)
            {
                parent::$this->getNombre();
            }

        }
    }
    
}

?>